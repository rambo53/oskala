﻿
function validationAsynch(form) {

    let siretInput = form.find("#numeroSiret");
    let mailInput = form.find("#mail");
    
    let validSiret = false;
    let validMail = false;


    mailInput.on('change keyup', function () {

        $(mailInput).closest(".div-container-sample").find(".next-btn").addClass("disabled").attr("disabled", "disabled");

        validateVal("../Login/validMail?mail=", mailInput, validMail, authorizeChangingPage);

    })


    siretInput.on('change keyup', function () {

        $(siretInput).closest(".div-container-sample").find(".next-btn").addClass("disabled").attr("disabled", "disabled");

        validateVal("../Login/validSiret?siret=", siretInput, validSiret, authorizeChangingPage)

    })

}


function validateVal(url, el, bool, callback) {

    getMethod(url + el.val(), null, function (result) {

        if (result.Result.errorCode == 400 || result.Result.errorCode == 500) {

            bool = result.Result.isSuccess;

            callback($(el).closest(".div-container-sample"), bool);

            Swal.fire({
                icon: 'error',
                title: result.Result.errorMessage,
                text: '',
            });

        }
        else {

            currentBool = result.Result.isSuccess;

            callback($(el).closest(".div-container-sample"), bool);
        }

    });
}


function authorizeChangingPage(div, bool) {

    if (bool) {
        div.find(".next-btn").removeClass("disabled").removeAttr("disabled"); 
    }

}




function validateFormCreaContact(form) {

        let contact = {
            title: $(form).find("input[name=titre]:checked").val().trim(),
            lastName: $("#contactNom").val().trim(),
            firstName: $("#contactPrenom").val().trim(),
            mobilPhone: $("#telephonePortable").val().trim(),
            mail: $("#mail").val().trim(),
            password: $("#password").val().trim(),
            companyName: $("#entrepriseNom").val().trim(),
            adresse: $("#adresseEntreprise").val().trim(),
            adresse2: $("#complementAdresseEntreprise").val().trim(),
            postCode: parseInt($("#codePostalEntreprise").val()),
            city: $("#villeEntreprise").val().trim(),
            isMain: true,
        }

        var tabContact = new Array();
        tabContact.push(contact);

        let company = {
            companyName: $("#entrepriseNom").val().trim(),
            country: $("#pays").val().trim(),
            legalStatus: $("#formeJuridique").val(),
            siretCode: $("#numeroSiret").val().trim(),
            adresse: $("#adresseEntreprise").val().trim(),
            adresse2: $("#complementAdresseEntreprise").val().trim(),
            postCode: parseInt($("#codePostalEntreprise").val().replace(" ", "")), //si appel réseau penser ajouter replace sinon format 53 100
            city: $("#villeEntreprise").val().trim(),
            contacts: tabContact,
            idAbonnement: $("#aboId").attr("value"),
        };

        // showBsProgress("progressModal", "Identification", "Connexion au compte en cours...", { dialogSize: 'm' });


        Swal.fire('Enregistrement de votre compte...');


    postMethod("../Login/RegisterContact", company, function (result) {

            if (result.isSuccess) {
                Swal.fire(
                    'Votre compte est enregistré.',
                    '',
                    'success'
                );
            }
            else {
                Swal.fire({
                    icon: 'error',
                    title: result.errorMessage,
                    text: '',
                });
            }

        });


    /*},
        invalidHandler: function (event, validator) {
            var errors = validator.numberOfInvalids();

        }

        })*/
    

}

function bindSubscriptionItems(selecteur, obj) {
    //itération sur mes data bind prop dans mon objet cloné

    $(selecteur).find('[data-bind-prop]').each(function (j, el) {

        let target = "";
        let prop = obj[$(this).attr('data-bind-prop')];

        //itération sur ma prop si c'est une collection

        if ($.isArray(prop)) {

            $(el).parent().find(".clone").remove();

            $(prop).each(function (k, tabEl) {


                let newEl = $(el).clone();
                newEl.addClass("clone");
                newEl.text("- " + tabEl);

                $(el).parent().append(newEl);
            })

        }
        else {

            target = $(el).attr('data-bind-src') || "";

            switch (target) {
                case "": $(this).text(prop); break;
                case "text": $(this).text(prop); break;
                case "html": $(this).html(prop); break;
                case "class": $(this).addClass(prop); break;
                case "tooltip": $(this).addClass(prop); break;

                default: $(this).attr(target, prop); break;
            }
        }
    });
}



